﻿Imports System.Runtime.InteropServices
Imports System.Text
Imports System.Threading
Imports FlaUI.Core
Imports FlaUI.Core.AutomationElements
Imports FlaUI.UIA3
Imports Variaveis



Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        AgentToolbarLogin()

    End Sub



    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim appToolBar = FlaUI.Core.Application.Attach("AgentToolbar")

        parentobjecthandle = appToolBar.MainWindowHandle

        PostMessage(parentobjecthandle, WM_LBUTTONDOWN, MK_LBUTTON, MakeDWord(239, 13))
        PostMessage(parentobjecthandle, WM_LBUTTONUP, 0, MakeDWord(239, 13))
        ' Play button on program
        ' The '142' and '84' values were obtained from the orginal programs windows messages when a button click was performed
        ' Use Winspector to monitor messages being sent to the parent object of the button you wish to control this allows you to obtain the above values

    End Sub


    Private Declare Auto Function PostMessage Lib "user32.dll" (ByVal hwnd As IntPtr, ByVal wMsg As Integer, ByVal wParam As Integer, ByVal lParam As Integer) As Integer
    Private Declare Auto Function GetParent Lib "user32.dll" (ByVal hWnd As IntPtr) As IntPtr

    Public Const WM_LBUTTONDOWN = &H201
    Public Const WM_LBUTTONUP = &H202
    Public Const MK_LBUTTON = &H1

    Dim parentobjecthandle As IntPtr

    Private Function MakeDWord(ByVal LoWord As Integer, ByVal HiWord As Integer) As Long
        MakeDWord = (HiWord * &H10000) Or (LoWord And &HFFFF&)
        ' Construct the 32bit Integer based on the 2x 16bit HI / LOW values
    End Function

    Public ListaElementosPausa As New List(Of AutomationElement)
    Public Automation = New UIA3Automation

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click

        Automation = New UIA3Automation
        Dim windows As AutomationElements.AutomationElement = Automation.GetDesktop()

        Dim elementGrupo = windows.FindAllDescendants(Function(x) x.ByAutomationId("2361680"))

        If elementGrupo.Length = 0 Then
            Dim elementGrupo2 = windows.FindAllDescendants(Function(x) x.ByAutomationId("1575736")).FirstOrDefault
            elementGrupo2.Click()
        End If

        elementGrupo = windows.FindAllDescendants(Function(x) x.ByClassName("TListBox"))

        If elementGrupo IsNot Nothing Then
            For Each elePausa In elementGrupo.First.FindAllChildren()
                If elePausa.Name <> "Vertical" Then
                    ListaElementosPausa.Add(elePausa)
                    pausaComboBox.Items.Add(elePausa.Name)
                End If
            Next
        End If

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click



        '2360744

        'Automation = New UIA3Automation
        'Dim windows As AutomationElements.AutomationElement = Automation.GetDesktop()

        'Dim elementGrupo = windows.FindAllDescendants(Function(x) x.ByAutomationId("2361680"))
        'If elementGrupo Is Nothing Then
        '    Automation = New UIA3Automation
        '    Dim windows2 As AutomationElements.AutomationElement = Automation.GetDesktop()

        '    Dim elementGrupo2 = windows.FindAllDescendants(Function(x) x.ByAutomationId("2360744")).FirstOrDefault
        '    elementGrupo2.Click()
        'End If

        'Dim pausaSelec = pausaComboBox.Text

        'Dim elePausaSelec = ListaElementosPausa.Where(Function(x) x.Name = pausaSelec).FirstOrDefault.AsMenuItem()
        'elePausaSelec.FocusNative()
        'elePausaSelec?.Invoke()


        AgentToolbarPausa("Lanche")

    End Sub


    <DllImport("user32.dll")>
    Private Shared Function SendMessage(ByVal hWnd As IntPtr, ByVal Msg As Int32, ByVal wParam As IntPtr, ByVal lParam As StringBuilder) As IntPtr

    End Function

    Const WM_GETTEXT As Int32 = &HD

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click

        Automation = New UIA3Automation
        Dim windows As AutomationElements.AutomationElement = Automation.GetDesktop()

        Dim elementGrupo = windows.FindAllDescendants(Function(x) x.ByAutomationId("3015872")).FirstOrDefault

        Dim sb As StringBuilder = New StringBuilder(256)
        Dim aaa = SendMessage(elementGrupo.FrameworkAutomationElement.NativeWindowHandle, WM_GETTEXT, CType(256, IntPtr), sb)

        Dim appToolBar = FlaUI.Core.Application.Attach("AgentToolbar")

        Dim sb2 As StringBuilder = New StringBuilder(256)
        Dim aaa2 = SendMessage(appToolBar.MainWindowHandle.ToInt32, WM_GETTEXT, CType(256, IntPtr), sb2)


    End Sub





#Region "WIN32"

    <DllImport("user32.dll", SetLastError:=True, CharSet:=CharSet.Auto)>
    Private Shared Function FindWindow(
 ByVal lpClassName As String,
 ByVal lpWindowName As String) As IntPtr
    End Function
    <DllImport("user32.dll")>
    Private Shared Function GetWindowPlacement(ByVal hWnd As IntPtr, ByRef lpwndpl As WINDOWPLACEMENT) As Boolean
    End Function
    <DllImport("user32.dll")>
    Private Shared Function SetWindowPlacement(ByVal hWnd As IntPtr, ByRef lpwndpl As WINDOWPLACEMENT) As Boolean
    End Function

    <DllImport("user32.dll", SetLastError:=True, CharSet:=CharSet.Auto)>
    Public Shared Function SetParent(ByVal hWndChild As IntPtr, ByVal hWndNewParent As IntPtr) As IntPtr
    End Function
    Private Structure RECT
        Public Left As Integer
        Public Top As Integer
        Public Right As Integer
        Public Bottom As Integer
        Public Sub New(ByVal X As Integer, ByVal Y As Integer, ByVal X2 As Integer, ByVal Y2 As Integer)
            Me.Left = X
            Me.Top = Y
            Me.Right = X2
            Me.Bottom = Y2
        End Sub
    End Structure

    Private Structure WINDOWPLACEMENT
        Public Length As Integer
        Public flags As Integer
        Public showCmd As ShowWindowCommands
        Public ptMinPosition As POINTAPI
        Public ptMaxPosition As POINTAPI
        Public rcNormalPosition As RECT
    End Structure

    Enum ShowWindowCommands As Integer
        Hide = 0
        Normal = 1
        ShowMinimized = 2
        Maximize = 3
        ShowMaximized = 3
        ShowNoActivate = 4
        Show = 5
        Minimize = 6
        ShowMinNoActive = 7
        ShowNA = 8
        Restore = 9
        ShowDefault = 10
        ForceMinimize = 11
    End Enum

    Public Structure POINTAPI
        Public X As Integer
        Public Y As Integer
        Public Sub New(ByVal X As Integer, ByVal Y As Integer)
            Me.X = X
            Me.Y = Y
        End Sub
    End Structure


#End Region


    Public Sub AgentToolbarLogin()
        Try

            If Process.GetProcessesByName("AgentToolbar").Length > 0 Then
                Process.GetProcesses().Where(Function(x) x.ProcessName = "AgentToolbar").First.Kill()
            End If

            Dim psi As New ProcessStartInfo()
            psi.WorkingDirectory = "C:\Program Files\GENESYS\"
            psi.FileName = "C:\Program Files\GENESYS\Launcher.exe"
            psi.WindowStyle = ProcessWindowStyle.Hidden
            psi.CreateNoWindow = True
            psi.RedirectStandardOutput = True
            psi.UseShellExecute = False
            Process.Start(psi)


            System.Threading.Thread.Sleep(3000)

            While Process.GetProcessesByName("AgentToolbar").Length = 0

            End While

            While Process.GetProcessesByName("AgentToolbar").First.MainWindowHandle = 0

            End While

            System.Threading.Thread.Sleep(10000)

            Dim Automation = New UIA3Automation()
            Dim windows As AutomationElements.AutomationElement = Automation.GetDesktop()

            Dim wdw As Window = windows.FindFirstDescendant(Function(x) x.ByName("Controle de Segurança")).AsWindow

            Dim pwdTextBox = windows.FindFirstDescendant(Function(x) x.ByClassName("TEdit")).AsTextBox()
            pwdTextBox.Focus()
            pwdTextBox.Patterns.Value.Pattern.SetValue("foc21are")

            Dim btnOK = windows.FindFirstDescendant(Function(x) x.ByText("OK")).AsButton()
            btnOK?.Invoke()

            hWndAgentToolbar = FindWindow(Nothing, "AgentToolbar")

            AgentToolbarAlteraModo(AgentToolbarModo.Normal, "")

        Catch ex As Exception

        End Try
    End Sub

    Public Sub AgentToolbarPausa(Pausa As String)
        Try

            AgentToolbarAlteraModo(AgentToolbarModo.Oculto, "Pausa")

            Dim Tentativas = 0
            Dim index = 2

CriaListaPausa:

            Automation = New UIA3Automation
            Dim windows As AutomationElements.AutomationElement = Automation.GetDesktop()

            Dim TPanelPrincipal = windows.FindFirstDescendant(Function(x) x.ByClassName("TPanel"))
            Dim TPanelPausa = TPanelPrincipal.FindChildAt(index)
            TPanelPausa.Click()

            Dim TListBox = windows.FindAllDescendants(Function(x) x.ByClassName("TListBox"))

            If TListBox.Length = 0 Then

                If Tentativas >= 3 Then
                    MsgBox("Não foi possível atribuir a pausa!", vbInformation, "Único")
                    System.Threading.Thread.Sleep(500)
                    GoTo FinalPausa
                Else
                    Tentativas += 1
                End If

                index = If(index = 2, 1, 2)

                GoTo CriaListaPausa
            End If

            If TListBox.Length > 0 Then
                For Each elePausa In TListBox.First.FindAllChildren()
                    If elePausa.Name = Pausa Then
                        Dim btnPausa = elePausa.AsMenuItem()
                        btnPausa.FocusNative()
                        btnPausa?.Invoke()
                        System.Threading.Thread.Sleep(500)
                        GoTo FinalPausa
                    End If
                Next
            End If

        Catch ex As Exception

        End Try
FinalPausa:
        AgentToolbarAlteraModo(AgentToolbarModo.Normal, "")
    End Sub


    Public AgentToolbarModoAtual As AgentToolbarModo = AgentToolbarModo.Normal

    Public Enum AgentToolbarModo
        Normal = 1
        Oculto = 2
        Restaurar = 3
    End Enum

    Public Sub AgentToolbarAlteraModo(Modo As AgentToolbarModo, Settings As String)
        Try

            Dim X As Integer = 0
            Dim Y As Integer = 0
            Dim Width As Integer = 0
            Dim Height As Integer = 33

            If Settings = "Pausa" Then
                Height = 300
            End If

            Select Case Modo

                Case AgentToolbarModo.Normal

                    AgentToolbarModoAtual = AgentToolbarModo.Oculto

                    Dim wp As WINDOWPLACEMENT
                    wp.Length = Marshal.SizeOf(wp)
                    GetWindowPlacement(FindWindow(Nothing, "AgentToolbar"), wp)
                    Dim wp2 As WINDOWPLACEMENT
                    wp2.showCmd = ShowWindowCommands.ShowDefault
                    wp2.ptMinPosition = wp.ptMinPosition
                    wp2.ptMaxPosition = New POINTAPI(0, 0)
                    wp2.rcNormalPosition = New RECT(0, 0, 1, 1) 'this is the size I want
                    wp2.flags = wp.flags
                    wp2.Length = Marshal.SizeOf(wp2)
                    SetWindowPlacement(FindWindow(Nothing, "AgentToolbar"), wp2)

                Case AgentToolbarModo.Oculto

                    AgentToolbarModoAtual = AgentToolbarModo.Normal

                    Dim wp As WINDOWPLACEMENT
                    wp.Length = Marshal.SizeOf(wp)
                    GetWindowPlacement(FindWindow(Nothing, "AgentToolbar"), wp)
                    Dim wp2 As WINDOWPLACEMENT
                    wp2.showCmd = ShowWindowCommands.Show
                    wp2.ptMinPosition = wp.ptMinPosition
                    wp2.ptMaxPosition = New POINTAPI(0, 0)
                    wp2.rcNormalPosition = New RECT(0, 0, Me.Width, Height) 'this is the size I want
                    wp2.flags = wp.flags
                    wp2.Length = Marshal.SizeOf(wp2)
                    SetWindowPlacement(FindWindow(Nothing, "AgentToolbar"), wp2)

                Case AgentToolbarModo.Restaurar

                    Dim wp As WINDOWPLACEMENT
                    wp.Length = Marshal.SizeOf(wp)
                    GetWindowPlacement(FindWindow(Nothing, "AgentToolbar"), wp)
                    Dim wp2 As WINDOWPLACEMENT
                    wp2.showCmd = ShowWindowCommands.Show
                    wp2.ptMinPosition = wp.ptMinPosition
                    wp2.ptMaxPosition = New POINTAPI(0, 0)
                    wp2.rcNormalPosition = New RECT(0, 0, 800, 600) 'this is the size I want
                    wp2.flags = wp.flags
                    wp2.Length = Marshal.SizeOf(wp2)
                    SetWindowPlacement(FindWindow(Nothing, "AgentToolbar"), wp2)

            End Select


        Catch ex As Exception

        End Try
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        AgentToolbarAlteraModo(AgentToolbarModoAtual, "")
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        AgentToolbarAlteraModo(AgentToolbarModo.Restaurar, "")
    End Sub

    Public hWndAgentToolbar As IntPtr

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click

        Dim hwnd = FindWindow(Nothing, "AgentToolbar")

        If hWndAgentToolbar = 0 Then
            hWndAgentToolbar = hwnd
        End If

        SetParent(hwnd, PanelAgentToolbar.Handle)



    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        SetParent(hWndAgentToolbar, IntPtr.Zero)
    End Sub

    Public MonitoraMsg As Boolean = False

    Public Sub MessageHandlers()

        While True

            Try

                If MonitoraMsg = True Then

                    If Me.IsDisposed Then
                        Exit While
                    End If

                    Dim ListMessages As String() = {"Alerta de segurança", "Mensagem da página da web", "Erro de Script"}

                    Win32Utils.FechaJanelaPorTextoList("AgentToolbar", "AgentToolbar", ListMessages)

                End If


            Catch ex As Exception

            End Try

        End While

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim ThreadInicializaMessageHandler As New Thread(Sub() MessageHandlers())
        ThreadInicializaMessageHandler.SetApartmentState(ApartmentState.STA)
        ThreadInicializaMessageHandler.Start()
    End Sub
End Class
